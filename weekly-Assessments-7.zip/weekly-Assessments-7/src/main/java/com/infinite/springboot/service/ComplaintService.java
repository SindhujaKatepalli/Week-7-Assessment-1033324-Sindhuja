package com.infinite.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.springboot.model.Complaint;
import com.infinite.springboot.repository.ComplaintRepository;

@Service
public class ComplaintService {
	  @Autowired
	    private ComplaintRepository complaintRepository;
	    public Complaint createComplaint(Complaint complaint) {
	        return complaintRepository.save(complaint);

	    }

}

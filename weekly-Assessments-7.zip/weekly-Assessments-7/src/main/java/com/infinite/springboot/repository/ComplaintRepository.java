package com.infinite.springboot.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infinite.springboot.model.Complaint;

public interface ComplaintRepository extends JpaRepository<Complaint, Integer> {

}

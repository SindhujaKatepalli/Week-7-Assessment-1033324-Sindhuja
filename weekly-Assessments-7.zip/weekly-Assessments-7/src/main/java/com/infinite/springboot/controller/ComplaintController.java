package com.infinite.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infinite.springboot.model.Complaint;
import com.infinite.springboot.service.ComplaintService;

@RestController
@RequestMapping("/complaints")
public class ComplaintController {
	@Autowired
	private ComplaintService complaintService;
	@GetMapping("/form")

    public String showComplaintForm(Model model) {
        model.addAttribute("complaint", new Complaint());
        return "complaints";
    }
    @PostMapping

    public String submitComplaint(@ModelAttribute("complaint") Complaint complaint) {

        complaintService.createComplaint(complaint);

        return "redirect:/complaints";

    }
}
